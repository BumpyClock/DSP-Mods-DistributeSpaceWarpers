v1.0.7
- Updated for the new build
v1.0.4
- Fixed Remote logic so now warpers will be moved from remote ILS/PLS if local ILS/PLS does not have any warpers.
- Small refactor to reduce code duplication.

v1.0.3
- Updated logic to correctly grab Warpers from the local ILS/PLS
- Updated logic to remove Warpers from the local ILS/PLS using TakeItem instead of directly from the Warper slot