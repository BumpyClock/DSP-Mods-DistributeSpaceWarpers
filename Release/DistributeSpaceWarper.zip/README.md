***** I got original source from https://github.com/Fireball14/DSP-Mods/tree/master/DistributeSpaceWarper and rebuilt for new DSP version ****



This mod is different than the original Fireball14 and JClark mods in that it does not add an additional slot for Interstellar Logistics Station for warpers. thank you starfish for the idea.

If you want to disable warper demand for particular station, just tick off "Warpers reqiered" toggle.

Change log:

v 1.0.0
Initial release. Bugs expected